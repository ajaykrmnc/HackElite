import logo from './logo.svg';
import './App.css';
import Header from './components/Header'
function App() {
  return (
    <Header></Header>
  );
}

export default App;
